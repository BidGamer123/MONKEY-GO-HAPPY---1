var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["a6870703-0124-47f7-acff-dbe905f5014c","f7bbf5ea-7dd2-4cfd-86cd-db826e40c21d","5ce44e39-12ac-4a66-88cf-a87a0ed6a180","33841f90-7a53-4346-b956-e51d1961959b","11a1d3f4-7895-4386-8cd4-13843a38118f","36bced41-1a58-4520-882b-2069a5cbe2d3","86526186-5daa-4446-aaaf-db60f0eebe76"],"propsByKey":{"a6870703-0124-47f7-acff-dbe905f5014c":{"name":"monkey","sourceUrl":null,"frameSize":{"x":560,"y":614},"frameCount":10,"looping":true,"frameDelay":3,"version":"Vy77rsm9ZWlCmXx_IWsjPJtWbS4Y9UG2","loadedFromSource":true,"saved":true,"sourceSize":{"x":1680,"y":1842},"rootRelativePath":"assets/a6870703-0124-47f7-acff-dbe905f5014c.png"},"f7bbf5ea-7dd2-4cfd-86cd-db826e40c21d":{"name":"monkey_copy_1","sourceUrl":null,"frameSize":{"x":560,"y":614},"frameCount":1,"looping":true,"frameDelay":60,"version":"eY36SEFFkYccc5BsihPBOaZLKcXlc06U","loadedFromSource":true,"saved":true,"sourceSize":{"x":560,"y":614},"rootRelativePath":"assets/f7bbf5ea-7dd2-4cfd-86cd-db826e40c21d.png"},"5ce44e39-12ac-4a66-88cf-a87a0ed6a180":{"name":"Banana","sourceUrl":null,"frameSize":{"x":1080,"y":1080},"frameCount":1,"looping":true,"frameDelay":12,"version":"Kcwt7YtcI8l648F7ECcMLI_Sl0daW7n6","loadedFromSource":true,"saved":true,"sourceSize":{"x":1080,"y":1080},"rootRelativePath":"assets/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png"},"33841f90-7a53-4346-b956-e51d1961959b":{"name":"Stone","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"y8SoUU.jCuqQejVV7T8YbKfo2eZveMqv","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png"},"11a1d3f4-7895-4386-8cd4-13843a38118f":{"name":"textGameOver_1","sourceUrl":"assets/api/v1/animation-library/gamelab/jlwUdmDfQ.Fl8uZni7e_c3sVaNJCXBYL/category_gameplay/textGameOver.png","frameSize":{"x":412,"y":78},"frameCount":1,"looping":true,"frameDelay":2,"version":"jlwUdmDfQ.Fl8uZni7e_c3sVaNJCXBYL","loadedFromSource":true,"saved":true,"sourceSize":{"x":412,"y":78},"rootRelativePath":"assets/api/v1/animation-library/gamelab/jlwUdmDfQ.Fl8uZni7e_c3sVaNJCXBYL/category_gameplay/textGameOver.png"},"36bced41-1a58-4520-882b-2069a5cbe2d3":{"name":"restart","sourceUrl":null,"frameSize":{"x":64,"y":64},"frameCount":1,"looping":true,"frameDelay":12,"version":"aMzjzf6PJUtxShGn4n880l6hXYJlU1fx","loadedFromSource":true,"saved":true,"sourceSize":{"x":64,"y":64},"rootRelativePath":"assets/36bced41-1a58-4520-882b-2069a5cbe2d3.png"},"86526186-5daa-4446-aaaf-db60f0eebe76":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"WHnOMV13xEoyuQw0HjNY_RIUM40DBqlP","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/86526186-5daa-4446-aaaf-db60f0eebe76.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

  //game state
  var PLAY = 1;
  var END = 0;
  var gameState = PLAY;
  
  //monkey
  var player = createSprite(50, 305);
  player.scale=0.1;
  
  //game over
  var finish=createSprite(200,200);
  finish.setAnimation("textGameOver_1");
  finish.scale=0.5;
  
  //restart icon
  var restart=createSprite(190,265,10,10);
  restart.setAnimation("restart");
  
  //ground
  var ground = createSprite(200, 350,400,10);
  ground.shapeColor="black";
  
  //groups
  var FoodGroup=createGroup();
  var EnemyGroup=createGroup();
  
  //points
  var survivalTime=0;
  
  function draw(){
    
    //background
    background("lightblue");
   
   //colliding
    player.collide(ground);
    
    //game state is in play
    if (gameState === PLAY){
      
      //it means that the game over and restart icon will not be visible for whole game
      restart.visible=false;
      finish.visible=false;
    
    //animation of monkey
      player.setAnimation("monkey");
      
      //to makesure that banana and stone is visible in our game
      spawnBananas();
      spawnEnemies();
      
      //when space key is pressed the monkey will jump
      if(keyDown("space")&& player.y >= 305){
       player.velocityY=-18;
       }
       
       //gravity to make our monkey jump
      player.velocityY=player.velocityY+1;
       
       //to text score in our game
      stroke("black");
      textSize(20);
      fill("black");
      survivalTime=Math.ceil(frameCount/frameRate());
      text("Score = "+survivalTime,295,30);
      
      //if monkey is touching banana then it get destroyed
      if (player.isTouching(FoodGroup)){
        FoodGroup.destroyEach();
        survivalTime=survivalTime+10;
      }
       
       //if monkey is touching stone then game state = end
      if(player.isTouching(EnemyGroup)){
         gameState=END;
       }
      
      //game state = END
    }else if(gameState === END){
       
       //to text our points
       stroke("black");
      textSize(20);
      fill("black");
      text("Survival Time : "+survivalTime,100,50);
      
      //groups that are getting destroyed
      EnemyGroup.destroyEach();
      FoodGroup.destroyEach();
      
      //groups that dont have velocity in end state
      EnemyGroup.setVelocityXEach(0);
      FoodGroup.setVelocityXEach(0);
      
      //in end state thr restart icon and game over will be visible
      restart.visible=true;
      finish.visible=true;
      
      //in end state the monkey will become stop
      player.setAnimation("monkey_copy_1");
      
      //the restart icon will work when it is pressed
      if(mousePressedOver(restart)){
        gameState=PLAY;
      }
    }
    
    drawSprites();
  }
  
  function spawnBananas(){
    
    //the frame count of banana
    if (frameCount % 80 === 0) {
       
       //banana
      var banana = createSprite(600,250,40,10);
      banana.y = random(120,200);    
      banana.velocityX = -5;
      
      //assign lifetime to the variable
      banana.lifetime = 500;
      player.depth = banana.depth + 1;
      
      //add image of banana
       banana.setAnimation("Banana");
      banana.scale=0.05;
      
      
      
      //add each banana to the group
      FoodGroup.add(banana);
      
     }
  }
  
  function spawnEnemies(){
    
    //frame count
    if(World.frameCount%80===0){
      
      //stone
      var obstacle = createSprite(430, 318);
      obstacle.setAnimation("Stone");
      obstacle.scale=0.15;
      
      //lifetime of stone
      obstacle.lifetime=500;
      
      //velocity of stone
      obstacle.velocityX=-5;
      
      //ai of obstacle
      obstacle.setCollider("circle",0,0,130);
  
      EnemyGroup.add(obstacle);
      
   }
  }

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
